<div class="container profiler">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6  text-center">
            <div class="contents-rest">
                <h3>Reset Password</h3>
                <h5>YOUR PASSWORD HAS BEEN RESET SUCESSFULLY</h5>

                <div class="content-button2 pading1">
                    <a href="<?php echo site_url(); ?>">
                        <button class="bpft-btn">BACK TO HOME</button>
                    </a>
                </div>

            </div>
        </div>
        <div class="col-md-3">
        </div>
    </div>
</div>