<div class="content-center style-position">
                                <div class="icon-images">
                                    <img src="<?php echo base_url("webassets"); ?>/img/spe-icon.png">
                                    <img src="<?php echo base_url("webassets"); ?>/img/music_icon.png">
                                    <img src="<?php echo base_url("webassets"); ?>/img/mic_icon.png">
                                    <img src="<?php echo base_url("webassets"); ?>/img/cir_icon.png">
                                </div>
                                <div class="schedule-head ">
                                    <h5>blenders pride fashion tour</h5>
                                    <h4>2014 schedule</h4>
                                </div>
                            </div>
                            </div></div></div>
    <div class="mid-content">
                        <div class="container">
                            <div class="icon-head">
                               <div class="icon-sche">
                                        <img src="<?php echo base_url("webassets"); ?>/img/spebig.png"><span class="name-icon">style walk</span>
                                        <img src="<?php echo base_url("webassets"); ?>/img/musbig.png"><span class="name-icon">style beat</span>
                                        <img src="<?php echo base_url("webassets"); ?>/img/micbig.png"><span class="name-icon">style speak</span>
                                        
                                        <img src="<?php echo base_url("webassets"); ?>/img/circuit.png"><span class="name-icon">style tech</span>
                                        
                                    </div>
                                <div class="label-text">
                                    <span>bprc</span><i>BLENDERS PRIDE RESERVE COLLECTION</i>

                                </div>
                                <div class="label-text">
                                    <span>bpft</span><i>blenders pride fashion tour</i>

                                </div>
                            <div class="clearfix"></div>

                            </div>
                        </div>
                    </div>
                    <div class="hyderabad">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="city-head">
                                        <h4>hyderabad</h4>
                                        <h5>n convention</h5>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>nov
                                            <br><i>15</i>
                                        </p>
                                    </div>
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>nov
                                            <br><i>16</i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">rocky s + neeta lulla</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">boom bay central</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mic.png"><span class="name-icon">boman irani</span>
                                        <br>

                                    </div>
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">Pankaj &amp; Nidhi + Namrata Joshipura</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">Shaa'ir + Func</span>
                                        <br>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gurgaon">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="city-head">
                                        <h4>Gurgaon</h4>
                                        <h5>Leela Ambience</h5>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>nov
                                            <br><i>22</i>
                                        </p>
                                    </div>
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>nov
                                            <br><i>23</i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">rocky s + neeta lulla</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">boom bay central</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mic.png"><span class="name-icon">boman irani</span>
                                        <br>

                                    </div>
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">Little Shilpa + Gaurav Gupta</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">Grain Karsh featuring Kale with Ankur </span>
                                        <br>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mumbai">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="city-head">
                                        <h4>mumbai</h4>
                                        <h5>Grand Hyatt</h5>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>nov
                                            <br><i>29</i>
                                        </p>
                                    </div>
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>nov
                                            <br><i>30</i>
                                        </p>
                                    </div>
                                </div>


                                <div class="col-md-6">
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">Neeta Lulla + Suneet Varma</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">Midival Punditz</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mic.png"><span class="name-icon">Wasim Akram</span>
                                        <br>

                                    </div>

                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">Little Shilpa + Shivan &amp; Narresh</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">Ashvin &amp; Ash</span>
                                        <br>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="bangaluru">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="city-head">
                                        <h4>bengaluru</h4>
                                        <h5>The Leela Palace</h5>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>dec
                                            <br><i>6</i>
                                        </p>
                                    </div>
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>dec
                                            <br><i>7</i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">Varun Bahl + Abraham &amp; Thakore</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">Midival Punditz</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mic.png"><span class="name-icon">Chetan Bhagat</span>
                                        <br>

                                    </div>
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">Pankaj &amp; Nidhi + Namrata Joshipura</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">Shaa'ir + Func</span>
                                        <br>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="kolkata">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="city-head">
                                        <h4>kolkata</h4>
                                        <h5>The Oberoi Grand</h5>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>dec
                                            <br><i>12</i>
                                        </p>
                                    </div>
                                    <div class="hyderabd-text label-texts">
                                        <span>bprc</span>
                                        <p>dec
                                            <br><i>13</i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">Varun Bahl + Abraham &amp; Thakore</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">Midival Punditz</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mic.png"><span class="name-icon">Irrfan Khan</span>
                                        <br>

                                    </div>
                                    <div class="hyderabad-name">
                                        <img src="<?php echo base_url("webassets"); ?>/img/speaker.png"><span class="name-icon">Pankaj &amp; Nidhi + Namrata Joshipura</span>
                                        <br>
                                        <img src="<?php echo base_url("webassets"); ?>/img/mus.png"><span class="name-icon">Shaa'ir + Func</span>
                                        <br>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="space"></div>
                    <div class="inspired">
                        <div class="container inspired-text">
                            <div class="content-center">
                                <h4>MADE A NOTE OF THE DATES?</h4>
                                <a href="<?php echo site_url('website/blenderstyle'); ?>">
                                    <div class="inspired-win">

                                        <p>WIN AN INVITE</p>


                                    </div>
                                </a>
                                <a data-scroll href="#top"><span class="back-top">back to top</span></a>

                            </div>
                        </div></div></div>     <div>   <div>                   
                           