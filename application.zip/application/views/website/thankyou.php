<div class="container profiler">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6  text-center">
            <div class="contents1">
                <h3>Register</h3>
                <h5>Thank you for your details.</h5>

                <p class="h10">A link to confirm your registration has been sent your email
                    <br>address <span class="clr-gold"><?php echo $email;?></span>
                </p>
                <div class="content-button1 pading1">
                    <a>
                        <button>LOGIN NOW</button>
                    </a>
                </div>

            </div>
        </div>
        <div class="col-md-3">
        </div>
    </div>
</div>