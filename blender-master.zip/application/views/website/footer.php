<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

<!-- compiled and minified Bootstrap JavaScript -->
<script src="<?php echo base_url("webassets");?>/js/bootstrap.min.js"></script>

<script src="<?php echo base_url("webassets");?>/js/main.js"></script>

<script src="<?php echo base_url("webassets");?>/js/classie.js"></script>
<script src="<?php echo base_url("webassets");?>/js/sidebarEffects.js"></script>
<script src="<?php echo base_url("webassets");?>/js/masonry.pkgd.min.js"></script>
<!-- For the demo ad only -->
<script src="<?php echo base_url("webassets");?>/slider_js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url("webassets");?>/slider_js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url("webassets");?>/fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>
    <script type="text/javascript" src="<?php echo base_url("webassets");?>/fancybox/source/jquery.fancybox.pack.js?v=2.1.5"></script>
    <script type="text/javascript" src="<?php echo base_url("webassets");?>/js/isotope.pkgd.min.js"></script>


<!-- Script to Activate the Carousel -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-25397410-14', 'auto');
  ga('send', 'pageview');

</script>

</body>

</html>
