<nav class="st-menu st-effect-11" id="menu-11">
    <h2>Menu</h2>
    <ul>
        <li><a class="<?php if($page=="index") echo "active";?>" href="<?php echo site_url('website/index'); ?>">HOME</a></li>
        
        <li><a class="<?php if($page=="schedule") echo "active";?>" href="<?php echo site_url('website/schedule'); ?>">EVENT SCHEDULE</a></li>
        
        <li><a class="<?php if($page=="blenderstyle") echo "active";?>" href="<?php echo site_url('website/blenderstyle'); ?>">STYLE BLENDERS</a></li>
        
        <li><a class="<?php if($page=="invitelist") echo "active";?>" href="<?php echo site_url('website/invitelist'); ?>">INVITE LIST</a></li>
        
        <li><a class="" href="<?php echo base_url("")."archive";?>">BPFT 2013</a></li>
    </ul>
    
    <div class="copy">
        <p>designed by <span class="goldy">River</span>, <br>
an independent creative agency</p>
    </div>
</nav>