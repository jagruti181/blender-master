<div class="footer">
        <div class="container">
            <div class="content-center footer-text">
                <p> <a href="<?php echo site_url('website/termscondition');?>">Terms &amp; Conditions</a>
                    <a href="<?php echo site_url('website/privacy');?>">Privacy Policy</a> 
                </p>
                <p class="comp-text">Contact us: River (An Independent Creative Agency), 269 Udyog Vihar, Phase II, Gurgaon, Haryana </p> <p class="comp-text">© 2014 Blenders Pride Limited. All rights reserved</p>
            </div>
        </div>
    </div>