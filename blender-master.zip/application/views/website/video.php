<div class="videoonly">
<iframe width="100%" height="100%" src="//www.youtube.com/embed/CUxJONigQhc?rel=0&amp;controls=0&amp;showinfo=0&autoplay=1" frameborder="0" allowfullscreen></iframe>
</div>