Facebook-v4-PHP-CodeIgniter
===========================

Facebook PHP SDK for CodeIgniter based on Facebook PHP SDK (v.4)

> This repo is based on Facebook PHP SDK (v.4) Link: https://github.com/facebook/facebook-php-sdk-v4
