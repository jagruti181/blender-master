<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['twitter_consumer_token']		= 'NxbPJjrZZmHXEKoaWuaQsrs1Q';
$config['twitter_consumer_secret']		= 'OQnOm5JQzLbHNUTVLQ8XKdxLpiSmSmbaL3dc8gEeLWsDOd2cyA';
$config['twitter_access_token']			= '121427044-HcXcZQmEpecX1XKLdEC2Ygpgq76bUZRafcYYjq7W'; // Optional
$config['twitter_access_secret']		= 'gMMCX3ty3yb2udASgj9CT5U6OdjqAk8AMFSqA2JD81TnA'; // Optional

/* End of file twitter.php */
/* Location: ./application/config/twitter.php */